# README

此資料夾為 LOHAShare AI Platform 文件治理架構的一部分。

用途：
- 保留資料夾於 GitHub 中可見。
- 作為後續文件搬移、版本管理、Current / 99_Archive 分流的佔位檔。
- 若此資料夾已有正式文件，可保留或移除此 README.txt。

注意：
- Current/ 僅放目前正式可引用版本。
- 99_Archive/ 放同一主題的舊版本，不跨主題混放。
